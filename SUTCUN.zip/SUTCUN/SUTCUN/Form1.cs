﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SUTCUN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con;
        SqlCommand cmd, cmd1;
        SqlDataAdapter da;
        SqlDataReader dr;
        DataSet ds;

        public static string sqlcon = "Data Source=LAPTOP-S07UBKGL\\SQLEXPRESS;Initial Catalog=SUTCUN;Integrated Security=True";

        void griddoldur(string sql)
        {
            con = new SqlConnection(sqlcon);
            da = new SqlDataAdapter(sql, con);
            ds = new DataSet();
            con.Open();
            da.Fill(ds, "urunler");
            dataGridView1.DataSource = ds.Tables["urunler"];
            con.Close();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            griddoldur("select * from urunler");
        }
    }
}
